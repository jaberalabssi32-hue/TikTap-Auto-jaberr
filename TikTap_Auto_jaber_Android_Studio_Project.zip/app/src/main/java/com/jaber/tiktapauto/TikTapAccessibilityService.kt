package com.jaber.tiktapauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.accessibility.AccessibilityEvent

class TikTapAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var panel: View? = null
    private var running = false
    private var taps = 0L
    private lateinit var status: TextView
    private val tapLoop = object : Runnable {
        override fun run() {
            if (!running) return
            performTap()
            val interval = getSharedPreferences("tiktap", MODE_PRIVATE).getInt("interval", 180)
            handler.postDelayed(this, interval.toLong())
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun showPanel() {
        if (panel != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(0xEE171324.toInt())
        }
        val title = TextView(this).apply {
            text = "TikTap • JABER"
            textSize = 13f
            setTextColor(0xFFB69CFF.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "متوقف • 0"
            textSize = 12f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val toggle = Button(this).apply {
            text = "بدء التكبيس"
            setOnClickListener {
                if (running) stopTaps() else startTaps()
                text = if (running) "إيقاف التكبيس" else "بدء التكبيس"
            }
        }
        val close = Button(this).apply {
            text = "إخفاء"
            setOnClickListener { stopTaps(); removePanel() }
        }
        root.addView(title)
        root.addView(status)
        root.addView(toggle)
        root.addView(close)
        root.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val params = panel?.layoutParams as? WindowManager.LayoutParams ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x; startY = params.y
                        touchX = event.rawX; touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (event.rawX - touchX).toInt()
                        params.y = startY + (event.rawY - touchY).toInt()
                        windowManager?.updateViewLayout(panel, params)
                        return true
                    }
                }
                return false
            }
        })
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 180 }
        panel = root
        windowManager?.addView(root, params)
    }

    private fun startTaps() {
        if (running) return
        running = true
        taps = 0
        status.text = "يعمل • 0"
        handler.post(tapLoop)
    }

    private fun stopTaps() {
        running = false
        handler.removeCallbacks(tapLoop)
        if (::status.isInitialized) status.text = "متوقف • $taps"
    }

    private fun performTap() {
        val dm = resources.displayMetrics
        val prefs = getSharedPreferences("tiktap", MODE_PRIVATE)
        val x = (dm.widthPixels * prefs.getInt("x", 92) / 100f)
        val y = (dm.heightPixels * prefs.getInt("y", 72) / 100f)
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 45)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                taps++
                if (::status.isInitialized && running) status.text = "يعمل • $taps"
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {}
        }, null)
    }

    private fun removePanel() {
        panel?.let { windowManager?.removeView(it) }
        panel = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopTaps() }
    override fun onDestroy() {
        stopTaps()
        removePanel()
        super.onDestroy()
    }
}
