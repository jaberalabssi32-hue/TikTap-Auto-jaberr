package com.jaber.tiktapauto

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("tiktap", MODE_PRIVATE)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(0xFF101018.toInt())
        }
        fun text(value: String, size: Float = 16f) = TextView(this).apply {
            text = value; textSize = size; setTextColor(0xFFF5F5FF.toInt())
            setPadding(0, 10, 0, 10)
        }
        val title = text("TikTap Auto jaber", 26f)
        title.setTextColor(0xFF7C4DFF.toInt())
        layout.addView(title)
        layout.addView(text("Gaming edition  •  Android 7.0+"))
        layout.addView(text("اضبط موقع زر الإعجاب كنسبة من الشاشة. ابدأ بقيم تقريبية ثم جرّب وعدّل."))
        val xInput = EditText(this).apply {
            hint = "X كنسبة مئوية (مثال 92)"
            setText(prefs.getInt("x", 92).toString())
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFFAAAAAA.toInt())
            inputType = 2
        }
        val yInput = EditText(this).apply {
            hint = "Y كنسبة مئوية (مثال 72)"
            setText(prefs.getInt("y", 72).toString())
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFFAAAAAA.toInt())
            inputType = 2
        }
        val speedInput = EditText(this).apply {
            hint = "الفاصل بين الضغطات بالمللي ثانية (150–1000)"
            setText(prefs.getInt("interval", 180).toString())
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFFAAAAAA.toInt())
            inputType = 2
        }
        listOf(xInput, yInput, speedInput).forEach {
            layout.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 58))
        }
        val save = Button(this).apply {
            text = "حفظ الإعدادات"
            setOnClickListener {
                val x = xInput.text.toString().toIntOrNull()
                val y = yInput.text.toString().toIntOrNull()
                val interval = speedInput.text.toString().toIntOrNull()
                if (x == null || y == null || interval == null || x !in 0..100 || y !in 0..100 || interval !in 150..1000) {
                    Toast.makeText(this@MainActivity, "تحقق من القيم: X/Y من 0 إلى 100 والفاصل 150–1000", Toast.LENGTH_LONG).show()
                } else {
                    prefs.edit().putInt("x", x).putInt("y", y).putInt("interval", interval).apply()
                    Toast.makeText(this@MainActivity, "تم حفظ الإعدادات", Toast.LENGTH_SHORT).show()
                }
            }
        }
        layout.addView(save)
        val enable = Button(this).apply {
            text = "1) تفعيل خدمة إمكانية الوصول"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        layout.addView(enable)
        val open = Button(this).apply {
            text = "2) فتح تيك توك"
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage("com.zhiliaoapp.musically")
                    ?: packageManager.getLaunchIntentForPackage("com.ss.android.ugc.trill")
                if (launch != null) startActivity(launch)
                else Toast.makeText(this@MainActivity, "لم يتم العثور على تيك توك", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(open)
        layout.addView(text("بعد التفعيل سيظهر زر عائم للتشغيل والإيقاف. اترك التطبيق مفتوحاً أثناء الاستخدام.", 13f))
        setContentView(layout)
    }
}
