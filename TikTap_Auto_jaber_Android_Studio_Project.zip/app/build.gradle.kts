plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.jaber.tiktapauto"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.jaber.tiktapauto"
        minSdk = 24
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
